# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['styler_utils',
 'styler_utils.api',
 'styler_utils.api.contrib',
 'styler_utils.api.contrib.sqlalchemy']

package_data = \
{'': ['*']}

install_requires = \
['fastapi>=0.100.0,<0.101.0']

setup_kwargs = {
    'name': 'styler-utils',
    'version': '0.1.0',
    'description': '',
    'long_description': 'STYLER-UTILS',
    'author': 'Illia Kravets',
    'author_email': 'illia.kravets@mint.ai',
    'maintainer': 'None',
    'maintainer_email': 'None',
    'url': 'None',
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'python_requires': '>=3.10,<4.0',
}


setup(**setup_kwargs)
