DEFAULT_ACTIONS = {
    "get": "list",
    "post": "create"
}

DEFAULT_DETAIL_ACTIONS = {
    "get": "retrieve",
    "patch": "update",
    "delete": "delete"
}